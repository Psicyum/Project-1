import './App.css'
import Button from './components/Button/Button'
import Input from './components/Input/Input'

function App() {

  return (
    <>
        <div className="boody">
          <div className="login-content">
            <div>
              <img src="foto.webp" alt="foto" id='foto'/>
            </div>
            <div className="form">
              <div className='text-content'>
                <h1>Get Started</h1>
                <h4>Welcome to HexaStudio - Let's get started</h4>
              </div>
              <div className="divisor"></div>

              <div className="form-content">
                <div className='userPass'>
                  <label htmlFor="mail">Your Email</label>
                  <Input placeholder='hi@hexastudio.in' classe='input-content'/>
                </div>
                <div className='userPass'>
                  <label htmlFor="pass">Create a new password</label>
                  <Input valor="000000" tipo='password' classe='input-content'/>
                </div>
                <Button nome="Create new account" classe="btn-acess"/>
                <span id='the-span'>Already have account? <a href="#" id='make-login'>Login</a></span>
              </div>
            </div>
          </div>
        </div>
    </>
  )
}

export default App

import React from 'react'
import './Button.css'

const Button = ({tipo, nome, classe}) => {
  return (
    <button className={classe} type={tipo}>{nome}</button>
  )
}

export default Button
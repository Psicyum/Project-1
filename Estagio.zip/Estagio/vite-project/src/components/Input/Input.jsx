import React from 'react'
import './Input.css'

const Input = ({tipo, nome, valor, id, placeholder, classe}) => {
  return (
    <input type={tipo} name={nome} value={valor} id={id} placeholder={placeholder} className={classe}/>
  )
}

export default Input